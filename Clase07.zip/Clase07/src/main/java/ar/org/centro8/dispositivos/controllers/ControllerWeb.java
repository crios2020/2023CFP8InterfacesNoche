package ar.org.centro8.dispositivos.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class ControllerWeb {
    
    @GetMapping("/")
    public String getIndex(){
        return "index";
    }

}
